import pandas as pd
import numpy as np
from datetime import datetime, date
import math
from typing import Optional, Dict, Any, List


PROCESS_STEPS = ['수주', '시방', '자재', '생산', '검사', '포장', '출고']

# 컬럼 → 공정 단계 매핑
STEP_DATE_MAP = {
    '수주':  {'planned': '수주일자',        'actual': None},
    '시방':  {'planned': '시방예상일',      'actual': '시방출도일'},
    '자재':  {'planned': '자재예상일',      'actual': '자재입고일'},
    '생산':  {'planned': '생산완료일',      'actual': None},
    '검사':  {'planned': '검사예상일',      'actual': None},
    '포장':  {'planned': '포장완료예상일',   'actual': '포장완료일'},
    '출고':  {'planned': '최종납기일',      'actual': None},
}


def safe_date(val):
    """Convert various date formats to ISO string safely."""
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    if isinstance(val, (datetime, date, pd.Timestamp)):
        try:
            return pd.Timestamp(val).strftime('%Y-%m-%d')
        except:
            return None
    if isinstance(val, (int, float)):
        try:
            s = str(int(val))
            if len(s) == 8:
                return f"{s[:4]}-{s[4:6]}-{s[6:]}"
        except:
            pass
    return None


def infer_current_step(row) -> str:
    """Determine the current step based on which dates are filled."""
    if pd.notna(row.get('포장완료일')):
        return '출고'
    if pd.notna(row.get('생산완료일')):
        return '포장'
    if pd.notna(row.get('자재입고일')):
        return '생산'
    if pd.notna(row.get('시방출도일')):
        return '자재'
    if pd.notna(row.get('수주일자')):
        return '시방'
    return '수주'


def infer_status(row) -> str:
    """Determine status: 완료/지연/진행중."""
    today = pd.Timestamp.now()
    
    if pd.notna(row.get('포장완료일')):
        return '완료'
    
    due_col = '최종납기일' if pd.notna(row.get('최종납기일')) else '요구납기일'
    due_val = row.get(due_col)
    if pd.notna(due_val):
        try:
            due_date = pd.Timestamp(due_val)
            if today > due_date:
                return '지연'
        except:
            pass
    
    return '진행중'


def calc_progress(row) -> int:
    """Calculate progress percentage based on completed steps."""
    completed = 0
    total = len(PROCESS_STEPS)
    
    checks = [
        pd.notna(row.get('수주일자')),
        pd.notna(row.get('시방출도일')),
        pd.notna(row.get('자재입고일')),
        pd.notna(row.get('생산완료일')),
        pd.notna(row.get('검사예상일')),
        pd.notna(row.get('포장완료일')),
        False,  # 출고는 별도 필드 없음
    ]
    completed = sum(checks)
    return int((completed / total) * 100)


def calc_delay_days(row) -> int:
    """Calculate delay days from due date."""
    today = pd.Timestamp.now()
    due_col = '최종납기일' if pd.notna(row.get('최종납기일')) else '요구납기일'
    due_val = row.get(due_col)
    if pd.notna(due_val):
        try:
            due_date = pd.Timestamp(due_val)
            delta = (today - due_date).days
            return max(0, delta)
        except:
            pass
    return 0


class DataManager:
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.df: pd.DataFrame = pd.DataFrame()
        self._load()

    def _load(self):
        try:
            df = pd.read_excel(self.filepath)
            
            # 날짜 컬럼 자동 감지: "일자" 또는 "일" 포함
            date_cols = [col for col in df.columns if '일자' in str(col) or str(col).endswith('일')]
            
            for col in date_cols:
                df[col] = pd.to_datetime(df[col], errors='coerce')
            
            self.df = self._enrich(df)
            print(f"[DataManager] Loaded {len(self.df)} rows from {self.filepath}")
        except Exception as e:
            print(f"[DataManager] Load error: {e}")
            self.df = pd.DataFrame()

    def reload(self, filepath: str = None):
        if filepath:
            self.filepath = filepath
        self._load()

    def _enrich(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add computed columns."""
        df = df.copy()
        df['_current_step'] = df.apply(infer_current_step, axis=1)
        df['_status'] = df.apply(infer_status, axis=1)
        df['_progress'] = df.apply(calc_progress, axis=1)
        df['_delay_days'] = df.apply(calc_delay_days, axis=1)
        df['_row_id'] = df.index
        return df

    def _row_to_dict(self, row) -> Dict[str, Any]:
        """Convert a DataFrame row to a JSON-safe dict."""
        d = {}
        for col, val in row.items():
            if isinstance(val, (pd.Timestamp, datetime, date)):
                d[col] = val.strftime('%Y-%m-%d') if pd.notna(val) else None
            elif isinstance(val, float):
                d[col] = None if math.isnan(val) else val
            elif isinstance(val, np.integer):
                d[col] = int(val)
            elif isinstance(val, np.floating):
                d[col] = None if np.isnan(val) else float(val)
            else:
                d[col] = val
        return d

    def get_filtered_df(
        self,
        search: str = "",
        status_filter: str = "",
        company_filter: str = "",
        step_filter: str = "",
    ) -> pd.DataFrame:
        df = self.df.copy()
        
        if search:
            mask = (
                df['수주번호'].astype(str).str.contains(search, case=False, na=False) |
                df['업체명'].astype(str).str.contains(search, case=False, na=False) |
                df['프로젝트'].astype(str).str.contains(search, case=False, na=False) |
                df['품명'].astype(str).str.contains(search, case=False, na=False) |
                df['시스템명'].astype(str).str.contains(search, case=False, na=False)
            )
            df = df[mask]
        
        if status_filter and status_filter != "전체":
            df = df[df['_status'] == status_filter]
        
        if company_filter and company_filter != "전체":
            df = df[df['업체명'] == company_filter]
        
        if step_filter and step_filter != "전체":
            df = df[df['_current_step'] == step_filter]
        
        return df

    def get_processes(
        self,
        page: int = 1,
        page_size: int = 50,
        search: str = "",
        status_filter: str = "",
        company_filter: str = "",
        step_filter: str = "",
        sort_by: str = "수주번호",
        sort_dir: str = "asc",
    ) -> Dict:
        df = self.get_filtered_df(search, status_filter, company_filter, step_filter)
        
        total = len(df)
        total_pages = max(1, math.ceil(total / page_size))
        page = max(1, min(page, total_pages))
        
        # Sort
        if sort_by in df.columns:
            df = df.sort_values(sort_by, ascending=(sort_dir == "asc"), na_position='last')
        
        start = (page - 1) * page_size
        end = start + page_size
        page_df = df.iloc[start:end]
        
        items = [self._row_to_dict(row) for _, row in page_df.iterrows()]
        
        return {
            "items": items,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
        }

    def get_process_detail(self, order_no: str, ordseq: int) -> Optional[Dict]:
        mask = (self.df['수주번호'] == order_no) & (self.df['ordseq'] == ordseq)
        rows = self.df[mask]
        if rows.empty:
            return None
        row = rows.iloc[0]
        d = self._row_to_dict(row)
        
        # Build timeline
        timeline = []
        for step in PROCESS_STEPS:
            mapping = STEP_DATE_MAP.get(step, {})
            planned_col = mapping.get('planned')
            actual_col = mapping.get('actual')
            planned = safe_date(row.get(planned_col)) if planned_col else None
            actual = safe_date(row.get(actual_col)) if actual_col else None
            
            timeline.append({
                "step": step,
                "planned": planned,
                "actual": actual,
                "is_current": step == row['_current_step'],
                "is_done": actual is not None,
            })
        
        d['_timeline'] = timeline
        return d

    def update_process(self, order_no: str, ordseq: int, updates: Dict) -> bool:
        mask = (self.df['수주번호'] == order_no) & (self.df['ordseq'] == ordseq)
        if not self.df[mask].any().any():
            return False
        
        for col, val in updates.items():
            if col in self.df.columns:
                self.df.loc[mask, col] = val
        
        # Re-enrich the modified rows
        for idx in self.df[mask].index:
            self.df.at[idx, '_current_step'] = infer_current_step(self.df.loc[idx])
            self.df.at[idx, '_status'] = infer_status(self.df.loc[idx])
            self.df.at[idx, '_progress'] = calc_progress(self.df.loc[idx])
            self.df.at[idx, '_delay_days'] = calc_delay_days(self.df.loc[idx])
        
        # Persist to disk
        try:
            save_df = self.df.drop(columns=[c for c in self.df.columns if c.startswith('_')], errors='ignore')
            save_df.to_excel(self.filepath, index=False)
        except Exception as e:
            print(f"[DataManager] Save error: {e}")
        
        return True

    def get_kpi(self) -> Dict:
        df = self.df
        total = len(df)
        in_progress = len(df[df['_status'] == '진행중'])
        delayed = len(df[df['_status'] == '지연'])
        completed = len(df[df['_status'] == '완료'])
        
        return {
            "total": total,
            "in_progress": in_progress,
            "delayed": delayed,
            "completed": completed,
        }

    def get_process_load(self) -> List[Dict]:
        if self.df.empty:
            return []
        counts = self.df['_current_step'].value_counts()
        result = []
        for step in PROCESS_STEPS:
            result.append({
                "step": step,
                "count": int(counts.get(step, 0)),
                "delayed": int(len(self.df[(self.df['_current_step'] == step) & (self.df['_status'] == '지연')])),
            })
        return result

    def get_urgent_delays(self, limit: int = 5) -> List[Dict]:
        delayed = self.df[self.df['_status'] == '지연'].copy()
        delayed = delayed.sort_values('_delay_days', ascending=False).head(limit)
        result = []
        for _, row in delayed.iterrows():
            result.append({
                "수주번호": row.get('수주번호', ''),
                "ordseq": int(row.get('ordseq', 0)),
                "업체명": row.get('업체명', ''),
                "품명": row.get('품명', ''),
                "_current_step": row.get('_current_step', ''),
                "_delay_days": int(row.get('_delay_days', 0)),
                "_progress": int(row.get('_progress', 0)),
            })
        return result

    def get_company_distribution(self) -> List[Dict]:
        if self.df.empty:
            return []
        counts = self.df['업체명'].value_counts().head(10)
        return [{"name": k, "value": int(v)} for k, v in counts.items()]

    def get_monthly_trend(self) -> List[Dict]:
        df = self.df.copy()
        col = '수주일자'
        if col not in df.columns:
            return []
        df[col] = pd.to_datetime(df[col], errors='coerce')
        df = df.dropna(subset=[col])
        df['month'] = df[col].dt.to_period('M').astype(str)
        monthly = df.groupby('month').size().reset_index(name='count')
        monthly = monthly.sort_values('month').tail(12)
        return monthly.to_dict(orient='records')

    def get_unique_values(self, col: str) -> List[str]:
        if col not in self.df.columns:
            return []
        vals = self.df[col].dropna().unique().tolist()
        return sorted([str(v) for v in vals])
